import { defineConfig } from 'astro/config';
export default defineConfig({ output: 'static', site: 'https://indonesiatamilsangam.com' });
