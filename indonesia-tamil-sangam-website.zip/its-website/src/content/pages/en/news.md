---
title: "News and Announcements"
description: "Official updates, community notices and approved press releases."
eyebrow: "LATEST UPDATES"
---

## Official news

No announcements have been published yet. This page will carry notices approved by the Sangam, including event announcements, community updates and press releases.

Each article should include a clear headline, publication date, responsible author or committee, factual summary and contact for enquiries. Corrections should be made transparently.
