---
title: "Tamil Language and Culture"
description: "Explore Tamil language, literature, arts, traditions and heritage."
eyebrow: "LANGUAGE & HERITAGE"
---

## Celebrating Tamil heritage

Tamil has a rich literary and cultural tradition. This section is intended to provide educational material and community stories that help readers learn about Tamil language, arts, customs and heritage.

## Proposed topics

- Tamil language and literature
- Festivals and their cultural significance
- Music, dance, theatre and visual arts
- Oral histories and intergenerational learning
- Learning resources for families and young people

Content describing Sangam classes, programmes or partnerships must be added only after the committee confirms that they exist.
