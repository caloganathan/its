---
title: "About Indonesia Tamil Sangam"
description: "Learn about the organisation, its purpose, leadership and community activities."
eyebrow: "ABOUT THE SANGAM"
---

## About the organisation

Indonesia Tamil Sangam is presented on this website as a community platform for Tamil language, culture, heritage and connection in Indonesia. The wording on this page is a draft for committee review, not a verified constitutional statement.

## Draft vision — for committee approval

A connected Tamil community in Indonesia that celebrates its language and heritage while building meaningful relationships across generations.

## Draft mission — for committee approval

- Encourage the appreciation and transmission of Tamil language and cultural heritage.
- Provide opportunities for community connection and participation.
- Share reliable information about Sangam programmes and community activities.
- Encourage collaboration with cultural, educational and community organisations.

## Office bearers and committee members

**Pending official confirmation.** Names, positions, photographs and terms of office must be added from the current committee-approved list. No names have been inferred from the registration document.

## Advisory committee

**Pending official confirmation.** Add each adviser’s approved name, position and biography after receiving the authorised list.

## Organisation details

The uploaded Indonesian NIB records the registered name as *Persekutuan dan Perkumpulan Paguyuban Indonesia Tamil Sangam*. The registration document lists an office in Citra Tower Kemayoran, Central Jakarta. Please confirm that the contact details remain current before launch.
