---
title: "Contact and Registration"
description: "Contact Indonesia Tamil Sangam or register your interest in participating."
eyebrow: "GET IN TOUCH"
---

## Contact the Sangam

Email: [indonesiatamilsangaminfo@gmail.com](mailto:indonesiatamilsangaminfo@gmail.com)

Telephone: 085195548554

Office listed in the uploaded NIB: Citra Tower Kemayoran, Level 3, Unit H1, Kavling A6, Jl. Benyamin Sueb, Kebon Kosong, Kemayoran, Central Jakarta, DKI Jakarta 10630, Indonesia.

**Verification required:** confirm the public telephone number, email, office address and visiting arrangements before launch.

Use the registration and enquiry form below to prepare an email. The prototype does not store submissions or send them automatically.
