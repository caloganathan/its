---
title: "Community Resources"
description: "Useful community information and carefully sourced public resources."
eyebrow: "USEFUL INFORMATION"
---

## Resources for the community

This section is intended to collect useful information for Tamil families and community members in Indonesia.

Proposed categories include Tamil language learning, cultural resources, information for newly arrived families, official public-service links and frequently asked questions about the Sangam.

Government, immigration, legal, medical or emergency information must link to current authoritative sources and show when it was last reviewed. Sangam content should not be presented as professional legal or medical advice.
