---
title: "Privacy Policy"
description: "How this website handles information and enquiries."
eyebrow: "PRIVACY"
---

## Privacy notice — draft for approval

This website is a static information site. In this prototype, the registration form prepares an email draft in the visitor’s own email application; the website does not transmit or store the submitted form data.

If the Sangam later introduces a hosted form, analytics, mailing list, membership database or registration platform, this notice must be updated before launch to explain the data collected, purposes, recipients, retention, security, contact for privacy requests and applicable legal requirements.

Do not submit sensitive personal information through this prototype. The committee should review and approve the final privacy notice.
