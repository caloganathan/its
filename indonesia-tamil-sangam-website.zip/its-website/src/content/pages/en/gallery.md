---
title: "Gallery"
description: "Photographs and videos from approved Sangam events and activities."
eyebrow: "COMMUNITY MOMENTS"
---

## Photo and video archive

The gallery will be organised by event and year after approved photographs are supplied. Each album should include the event name, date, captions and accessible image descriptions.

Before publication, confirm permission to use the photographs and avoid exposing personal information in image backgrounds, name badges or documents.
