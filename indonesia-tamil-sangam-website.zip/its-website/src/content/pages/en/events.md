---
title: "Events and Programmes"
description: "Discover official events, cultural programmes and community gatherings."
eyebrow: "EVENTS"
---

## Upcoming events

No upcoming event has been published yet. Event listings will appear here after the Sangam confirms the programme.

## Event information

Each event page should state the official event name, date and local time, venue, organiser, participation requirements, registration method and contact details. Do not publish tentative dates as confirmed.

## Past events

After each event, add an approved summary, selected photographs with captions and the date. Obtain consent before publishing identifiable photographs, especially those of children.
