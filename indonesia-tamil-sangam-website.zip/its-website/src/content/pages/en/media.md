---
title: "Media and Press"
description: "Official organisation information and media enquiries."
eyebrow: "MEDIA & PRESS"
---

## Media enquiries

For press enquiries, please contact [indonesiatamilsangaminfo@gmail.com](mailto:indonesiatamilsangaminfo@gmail.com). The committee should designate an authorised spokesperson before media statements are issued.

## Media kit — to be completed

- Approved organisation description
- High-resolution logo files and usage guidance
- Current office-bearer list and authorised spokesperson
- Approved photographs and captions
- Published press releases

Do not treat draft mission statements or unverified biographical information as official facts.
