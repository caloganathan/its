---
title: "Join and Participate"
description: "Register your interest in membership, volunteering or community activities."
eyebrow: "GET INVOLVED"
---

## Be part of the community

Use the registration form to express interest in membership, volunteering, events or cultural collaboration. Submitting an enquiry does not itself establish membership.

Membership eligibility, fees, benefits, approval procedures and any required documents must be published only after the Sangam confirms its official policy.
